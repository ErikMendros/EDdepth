test_that("2D depth runs", {

  set.seed(1)

  n <- 100
  d <- 2

  x <- matrix(rnorm(d*n), ncol=d)
  data <- matrix(rnorm(d*n), ncol=d)

  depth <- ED(x, data)

  expect_length(depth, n)
})
