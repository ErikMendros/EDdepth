#' 2D Empirical Depth
#'
#' Computes empirical depth in 2 dimensions.
#'
#' @param X Data matrix (n x 2)
#' @param x Query point (length 2)
#' @return Depth value
#' @export
ED_2d <- function(X, x){

  X <- sweep(X, 2, x)
  X <- X[X[,1] != 0, , drop=FALSE]

  cond <- as.numeric(X[,2] > 0)
  ratio <- -X[,1] / X[,2]
  ord <- order(ratio)

  s <- cond[ord]
  n <- length(s)

  init <- sum(s)
  delta <- ifelse(s == 1, -1, 1)

  cts_vec <- c(init, init + cumsum(delta))
  cts <- c(1/(cts_vec/n), 1/(1-cts_vec/n))

  1/(1+sum(cts^2)/(2*n))
}
