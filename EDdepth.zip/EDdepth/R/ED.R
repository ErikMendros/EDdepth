#' Empirical Depth
#'
#' Computes empirical depth for 2D or 3D data.
#'
#' @param x Query matrix (m x d)
#' @param data Data matrix (n x d)
#' @return Numeric vector of depth values
#' @export
ED <- function(x, data){

  d <- ncol(data)
  n <- nrow(x)
  depth <- numeric(n)

  if(d == 2){
    for(i in seq_len(n)){
      depth[i] <- ED_2d(data, x[i,])
    }
  }

  if(d == 3){
    for(i in seq_len(n)){
      depth[i] <- ED_3d_cpp(data, x[i,])
    }
  }

  depth
}
