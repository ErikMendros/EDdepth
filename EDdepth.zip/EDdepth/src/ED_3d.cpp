#include <Rcpp.h>
using namespace Rcpp;

// ClosedForm(a, n)
inline double ClosedForm_cpp(double a, double n){
    return 2.0/(6 + 11*a + 6*a*a + a*a*a)
        + (2 + 2*a)/(a - n)
        - 10.0/(n - 1)
        + 10.0/n
        + 2*n/(6 + 11*a + 6*a*a + a*a*a)
        + (a + 2)/(n - 1 - a)
        + a/(n - a + 1);
}


// [[Rcpp::export]]
double ED_3d_cpp(NumericMatrix Y, NumericVector x){

    int N = Y.nrow();
    int d = Y.ncol();

    // Shift data: X = sweep(Y, 2, x)
    NumericMatrix X(N, d);
    for(int i=0; i<N; i++){
        for(int j=0; j<d; j++){
            X(i,j) = Y(i,j) - x[j];
        }
    }

    // Remove rows where X[,1] == 0
    std::vector<int> keep;
    keep.reserve(N);
    for(int i=0; i<N; i++){
        if(X(i,0) != 0) keep.push_back(i);
    }

    int n = keep.size();
    NumericMatrix X2(n, d);
    for(int i=0; i<n; i++){
        for(int j=0; j<d; j++){
            X2(i,j) = X(keep[i], j);
        }
    }

    // Y <- cbind(X[,1]/X[,3], X[,2]/X[,3], sign(X[,3]))
    NumericMatrix Yp(n, 3);
    int n1 = 0;
    for(int i=0; i<n; i++){
        double z = X2(i,2);
        Yp(i,0) = X2(i,0) / z;
        Yp(i,1) = X2(i,1) / z;
        Yp(i,2) = (z > 0 ? 1 : -1);
        if(z > 0) n1++;
    }
    int n0 = n - n1;

    // Compute ED correction term
    double ed = n - 3
        - ((n+1.0)/(n+1.0-n1) - (1 + (double)n1/n
        + R::choose(n1,2)/R::choose(n,2)
        + R::choose(n1,3)/R::choose(n,3)))
        - ((n+1.0)/(n+1.0-n0) - (1 + (double)n0/n
        + R::choose(n0,2)/R::choose(n,2)
        + R::choose(n0,3)/R::choose(n,3)));

    // Counts vector
    std::vector<double> Counts(n-1, 0.0);

    // Main loop
    for(int idx=0; idx<n; idx++){

        std::vector<double> X1, X2v, X3;
        std::vector<int> CLR, Labels;
        X1.reserve(n-1);
        X2v.reserve(n-1);
        X3.reserve(n-1);
        CLR.reserve(n-1);
        Labels.reserve(n-1);

        for(int j=0; j<n; j++){
            if(j == idx) continue;
            double dx1 = Yp(j,0) - Yp(idx,0);
            double dx2 = Yp(j,1) - Yp(idx,1);
            double dx3 = Yp(j,2);

            X1.push_back(dx1);
            X2v.push_back(dx2);
            X3.push_back(dx3);

            CLR.push_back(dx3 != Yp(idx,2));
            Labels.push_back(dx2 * dx3 > 0);
        }

        int m = n - 1;

        // Precompute ratio to avoid repeated division in sort comparator
        std::vector<double> ratio(m);
        for(int i=0; i<m; i++){
            ratio[i] = -X1[i] / X2v[i];
        }

        // Order = order(ratio)
        std::vector<int> ord(m);
        for(int i=0; i<m; i++) ord[i] = i;

        std::sort(ord.begin(), ord.end(),
                  [&](int a, int b){
                      return ratio[a] < ratio[b];
                  });

        // Apply ordering
        std::vector<int> Seq(m), Color(m);
        for(int i=0; i<m; i++){
            Seq[i] = Labels[ord[i]];
            Color[i] = CLR[ord[i]];
        }

        int EL = 0;
        for(int i=1; i<m; i++) EL += Seq[i];
        Counts[EL] += Color[0];

        for(int j=0; j<m-1; j++){
            if(Seq[j] == 0) EL++;
            if(Seq[j+1] == 1) EL--;
            Counts[EL] += Color[j+1];
        }
    }

    // SUM = Σ Counts[l] * ClosedForm(l-1, n)
    double SUM = 0.0;
    for(int l=1; l<n; l++){
        SUM += Counts[l-1] * ClosedForm_cpp(l-1, n);
    }

    ed -= 0.25 * SUM;

    return 1.0 / (1 + n - ed);
}